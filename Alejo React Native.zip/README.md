# react-native-asap

App desarrollada con:

- React Native
- Expo
- React Native Paper (UI)
- React Navigation

La misma es un mockup de una app de e-commerce.
Falta realizar:
- Validaciones de usuarios
- Lógica de operaciones para el carrito y el store
- Backend

Repo: https://github.com/Alejo-Martinez-Grau/react-native-asap
